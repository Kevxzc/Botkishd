const { proto } = (await import('@adiwajshing/baileys')).default

let handler = async (m, { conn, text, command, usedPrefix }) => {
	let M = proto.WebMessageInfo;
	if (!m.quoted) throw `Balas pesan dengan perintah *${usedPrefix + command}*`;
	if (!text) throw `Penggunaan: ${usedPrefix + command} <teks>\n\nContoh:\n${usedPrefix + command} tes`;
	let msgs = db.data.chats[m.chat].listStr;
    // Menggunakan regex yang fleksibel untuk mencocokkan teks
    let regex = new RegExp(text, 'i');
	if (Object.keys(msgs).find(k => regex.test(k))) throw `'${text}' telah terdaftar di List store`;
	msgs[text] = M.fromObject(await m.getQuotedObj()).toJSON();
	m.reply(`Berhasil menambahkan ${text} ke List Store.\n\nAkses dengan mengetik namanya`.trim());
}
handler.help = ['list'].map(v => 'add' + v + ' <teks>')
handler.tags = ['store', 'group', 'adminry']
handler.command = /^addlist$/i
handler.group = true
handler.admin = true

export default handler