import fs from 'fs'
let handler = async (m, { conn, usedPrefix }) => {
let teks = `❏「 _*SEWABOT*_ 」

❃ _*1 Minggu* Rp.9000 / Group_
❃ _*1 Bulan* 15.0000 / Group_
❃ _*Permanen* 30.000 / Group_

❏ *_Fitur_*
❃ _Antilink_
❃ _Welcome_
❃ _Enable_
❃ _Store List_
❃ _Promote/Demote_
❃ _HideTag_
❃ _Dan Lain Lain_

❏「 _*PREMIUM*_ 」
❃ _*1 Minggu:* Rp.5.000_
❃ _*1 Bulan:* Rp.10.000_
❃ _*Permanen:* Rp.15.000_

❏ keuntungan user premium?
🔓 unlock fitur *(Ketik .menuprem)*
🔓 limit Unlimited

❏ Minat? Silahkan Chat Nomor Owner
https://wa.me/${owner[0][0]}
`.trim()
await conn.sendFile(m.chat, fs.readFileSync('./media/thumbnail.jpg'), ' .thumbnailjpeg', teks, m, false)
}
handler.help = ['sewabot']
handler.tags = ['store']
handler.command = /^(sewabot|premium|sewa|prem)$/i

export default handler