let handler = async (m, { conn, command, usedPrefix, text, groupMetadata }) => {

if (!text) throw `Contoh:
${usedPrefix + command} Yang terserah`
let em = ['😀','😂','😃','🗿','🤤','😁','😐','🙂','☹️']

    let toM = a => '@' + a.split('@')[0]
    let ps = groupMetadata.participants.map(v => v.id)
    let a = ps.getRandom()
    let am = em.getRandom()
    conn.reply(m.chat, `Yang Paling *${text}* Adalah ${toM(a)} ${am}`, m, {mentions: [a]})
    
}
handler.help = ['yang'].map(v => v + ' <teks>')
handler.command = ['yang']
handler.tags = ['fun']

handler.group = true

export default handler