import FormData from "form-data";

async function processing(urlPath, method) {
    return new Promise(async (resolve, reject) => {
        const Methods = ["enhance", "recolor", "dehaze"];
        method = Methods.includes(method) ? method : Methods[0];

        const Form = new FormData();
        const scheme = `https://inferenceengine.vyro.ai/${method}`;

        Form.append("model_version", 1, {
            "Content-Transfer-Encoding": "binary",
            contentType: "multipart/form-data; charset=utf-8",
        });

        Form.append("image", Buffer.from(urlPath), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg",
        });

        Form.submit({
            url: scheme,
            host: "inferenceengine.vyro.ai",
            path: `/${method}`,
            protocol: "https:",
            headers: {
                "User-Agent": "okhttp/4.9.3",
                Connection: "Keep-Alive",
                "Accept-Encoding": "gzip",
            },
        }, function (err, res) {
            if (err) reject(err);

            let data = [];
            res.on("data", function (chunk) {
                data.push(chunk);
            });

            res.on("end", () => {
                resolve(Buffer.concat(data));
            });

            res.on("error", (e) => {
                reject(e);
            });
        });
    });
}

const handler = async (m, { conn, command }) => {
    const processType = {
        remini: conn.enhancer,
        color: conn.recolor,
        hdr: conn.hdr
    };

    const type = command === "remini" ? "enhance" : command;
    // Inisialisasi map dengan objek kosong jika tidak ditemukan
    const map = processType[command] || {};

    if (m.sender in map) {
        throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu!!";
    }

    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || q.mediaType || "";

    if (!mime) throw `Fotonya Mana?`;
    if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak didukung`;

    map[m.sender] = true;
    m.reply("_prosess.._");

    const img = await q.download?.();
    let error;
    try {
        const processedImage = await processing(img, type);
        conn.sendFile(m.chat, processedImage, "", "Done Results HD", m);
    } catch (er) {
        error = true;
    } finally {
        if (error) {
            m.reply("Proses Gagal :(");
        }
        delete map[m.sender];
    }
};

handler.help = ["hd"];
handler.tags = ["ai"];
handler.premium = false;
handler.group = false;
handler.limit = true;
handler.command = ["hd"];

export default handler;
/*
SCRIPT BY © VYNAA VALERIE 
•• recode kasih credits 
•• contacts: (t.me/VLShop2)
•• instagram: @vynaa_valerie 
•• (github.com/VynaaValerie) 
*/